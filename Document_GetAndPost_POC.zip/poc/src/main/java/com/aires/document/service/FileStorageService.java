package com.aires.document.service;

import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import com.aires.document.dto.FileReplaceDto;
import com.aires.document.dto.FileSuccRespDto;
import com.aires.document.dto.FileSuccessResponseDto;
import com.aires.document.dto.FileUploadModal;

public interface FileStorageService {
	FileSuccessResponseDto storeMultipleFile(List<FileUploadModal> fileUploadModals);

	FileSuccRespDto storeMultipleFile(FileUploadModal fileUploadModals);

	Resource loadFileAsResource(String fileName) throws FileNotFoundException;

	String moveFile(String path, String fromDir, String toDir);

	// boolean deleteFile(String path);
	FileReplaceDto replaceFile(String existFilePath, MultipartFile fileUploadModal) throws IOException;

	Resource loadFileAsResourceForUser(String filePathUri) throws FileNotFoundException;

	FileReplaceDto replaceFileNew(String existFilePath, BufferedImage fileUploadModal, String userId)
			throws IOException;

	String createFileName(String fileName);
}