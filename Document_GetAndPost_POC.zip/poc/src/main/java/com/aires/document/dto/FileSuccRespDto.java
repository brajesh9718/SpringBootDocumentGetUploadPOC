package com.aires.document.dto;

import java.nio.file.Path;
import java.util.List;

public class FileSuccRespDto {
	private String errorCode;
	private boolean success;
	private String errorDesc;
	private Path paths;
	
	
	public FileSuccRespDto(String errorCode, boolean success, String errorDesc, Path paths) {
		super();
		this.errorCode = errorCode;
		this.success = success;
		this.errorDesc = errorDesc;
		this.paths = paths;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public Path getPaths() {
		return paths;
	}
	public void setPaths(Path paths) {
		this.paths = paths;
	}
	
	
}
