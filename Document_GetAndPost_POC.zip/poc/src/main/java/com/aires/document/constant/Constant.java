package com.aires.document.constant;

public class Constant {
	private Constant() {
	}
	public static final String BASEURI="${baseuri}";
	public static final String POST_DOCUMENT="${postdocument}";
	public static final String GET_DOCUMENT="${getdocument}";
	public static final byte ACTIVE_STATUS=1;

}
