package com.aires.document.controller;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aires.document.constant.Constant;
import com.aires.document.dto.DocumentReq;
import com.aires.document.dto.DocumentResp;
import com.aires.document.dto.Response;
import com.aires.document.service.DocumentService;

/**
 * 
 * @author dharmendra.sonkar Document API Post Document and get Document byId
 * 
 */
@RestController
@RequestMapping(value = Constant.BASEURI)
public class DocumentController {
	Logger LOG = LoggerFactory.getLogger(DocumentController.class);
	@Autowired
	DocumentService documentService;
	@Autowired
	Environment env;

	/**
	 * Document POST API
	 * 
	 * @param MultipartFile type
	 */
	@PostMapping(value = Constant.POST_DOCUMENT)
	public ResponseEntity<Object> postDocument(DocumentReq documentReq) throws Exception {
		LOG.trace("Inside postDocument method: {}", documentReq);
		Response<Object> response = new Response<>();
		int resp = documentService.postDocument(documentReq);
		response.setResponseCode(env.getProperty("success.code"));
		response.setDescription(env.getProperty("success"));
		Map<String, Integer> map = new ConcurrentHashMap<>();
		map.put("documentId", resp);
		response.setData(map);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}

	/**
	 * Document GET API by documentId
	 * 
	 * @param documentId
	 */
	@GetMapping(value = Constant.GET_DOCUMENT)
	public ResponseEntity<Object> getDocumentById(@RequestParam Integer documentId) throws Exception {
		LOG.trace("Inside getDocumentById method: {}", documentId);
		Response<Object> response = new Response<>();
		DocumentResp resp = documentService.getDocumentById(documentId);
		response.setResponseCode(env.getProperty("success.code"));
		response.setDescription(env.getProperty("success"));
		response.setData(resp);
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
}
