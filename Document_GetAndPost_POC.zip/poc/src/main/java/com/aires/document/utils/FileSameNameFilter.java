package com.aires.document.utils;

import java.io.File;
import java.io.FilenameFilter;



public class FileSameNameFilter implements FilenameFilter{

	String fileName;
	
	public FileSameNameFilter(String fileName) {
		this.fileName=fileName;
	}

	@Override
	public boolean accept(File dir, String name) {
		if(name.startsWith(fileName)) {
			return true;
		}
		return false;
	}
}
