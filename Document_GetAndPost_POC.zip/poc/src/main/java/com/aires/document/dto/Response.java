package com.aires.document.dto;

public class Response<T> {
	
	private String description;
	private String responseCode;
	private T data;

	public Response() {

	}
	
	public Response(String description, String responseCode) {
		this.description = description;
		this.responseCode = responseCode;
	}

	public Response(String description, String responseCode, T data) {
		this.description = description;
		this.responseCode = responseCode;
		this.data = data;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode
	 *            the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the data
	 */
	public T getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(T data) {
		this.data = data;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Response [description=" + description + ", responseCode=" + responseCode + ", data=" + data + "]";
	}
}
