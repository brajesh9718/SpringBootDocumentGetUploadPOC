package com.aires.document.dto;

public class FileReplaceDto {
	private String path;
	private String contentType;
	private String extension;
	
	public FileReplaceDto() {
		// TODO Auto-generated constructor stub
	}
	
	public FileReplaceDto(String path, String contentType, String extension) {
		super();
		this.path = path;
		this.contentType = contentType;
		this.extension = extension;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getExtension() {
		return extension;
	}
	public void setExtension(String extension) {
		this.extension = extension;
	}
	
}
