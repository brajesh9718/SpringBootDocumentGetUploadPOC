package com.aires.document.dto;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadModal {
	private MultipartFile file;
	private String extension;
	private String dirName;

	public FileUploadModal(MultipartFile file, String extension, String dirName) {
		this.file = file;
		this.extension = extension;
		this.dirName = dirName;
	}

	public FileUploadModal() {
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getDirName() {
		return dirName;
	}

	public void setDirName(String dirName) {
		this.dirName = dirName;
	}

}
