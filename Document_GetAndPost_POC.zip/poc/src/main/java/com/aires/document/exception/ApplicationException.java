package com.aires.document.exception;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 8087006193926916540L;

	private String strNewErrorCode = "";

	public ApplicationException(final String errorMessage) {
		super(errorMessage);
	}

	public ApplicationException(final String errorCode, final String errorMessage) {
		super(errorMessage);
		this.strNewErrorCode = errorCode;
	}

	public ApplicationException(final Throwable t, final String errorMessage) {
		super(t);
		strNewErrorCode = errorMessage;
	}

	public String getErrorCode() {
		if (strNewErrorCode.equals("")) {
			return super.getMessage();
		}
		return strNewErrorCode;
	}

	public void setErrorCode(final String errorCode) {
		strNewErrorCode = errorCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GlobalException [strNewErrorCode=" + strNewErrorCode + "]";
	}

}
