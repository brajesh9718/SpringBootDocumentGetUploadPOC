package com.aires.document.utils;

import java.io.Serializable;
import java.util.List;

public class ErrorResponse implements Serializable {

	private static final long serialVersionUID = -1056161865319797443L;

	private String description;
	private String responseCode;
	private List<ErrorDetails> errors;

	/*
	 * public ErrorResponse() {
	 * 
	 * }
	 */

	public ErrorResponse(String description, String responseCode) {
		this.description = description;
		this.responseCode = responseCode;
	}

	public ErrorResponse(String description, String responseCode, List<ErrorDetails> errors) {
		this.description = description;
		this.responseCode = responseCode;
		this.errors = errors;
	}

	public ErrorDetails getErrorDetailsObj(final String errorCode, final String errorDescription) {
		return new ErrorDetails(errorCode, errorDescription);
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode
	 *            the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the errors
	 */
	public List<ErrorDetails> getErrors() {
		return errors;
	}

	/**
	 * @param errors
	 *            the errors to set
	 */
	public void setErrors(List<ErrorDetails> errors) {
		this.errors = errors;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ErrorResponse [description=" + description + ", responseCode=" + responseCode + ", errors=" + errors
				+ "]";
	}

	public class ErrorDetails implements Serializable {

		private static final long serialVersionUID = 2791301270942979305L;

		private String errorCode;
		private String errorDescription;

		public ErrorDetails(String errorCode, String errorDescription) {
			this.errorCode = errorCode;
			this.errorDescription = errorDescription;
		}

		/**
		 * @return the errorCode
		 */
		public String getErrorCode() {
			return errorCode;
		}

		/**
		 * @param errorCode
		 *            the errorCode to set
		 */
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}

		/**
		 * @return the errorDescription
		 */
		public String getErrorDescription() {
			return errorDescription;
		}

		/**
		 * @param errorDescription
		 *            the errorDescription to set
		 */
		public void setErrorDescription(String errorDescription) {
			this.errorDescription = errorDescription;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "ErrorDetails [errorCode=" + errorCode + ", errorDescription=" + errorDescription + "]";
		}
	}
}