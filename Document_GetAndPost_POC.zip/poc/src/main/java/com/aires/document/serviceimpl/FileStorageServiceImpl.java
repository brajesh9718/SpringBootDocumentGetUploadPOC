package com.aires.document.serviceimpl;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextException;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.aires.document.dto.FileReplaceDto;
import com.aires.document.dto.FileResponse;
import com.aires.document.dto.FileSuccRespDto;
import com.aires.document.dto.FileSuccessResponseDto;
import com.aires.document.dto.FileUploadModal;
import com.aires.document.properties.FileUploadProperties;
import com.aires.document.service.FileStorageService;
import com.aires.document.utils.FileSameNameFilter;


@Service
public class FileStorageServiceImpl implements FileStorageService {
	private Logger log=LoggerFactory.getLogger(FileStorageServiceImpl.class);
	
	private String fileStorageLocation="";
	@Autowired
	private FileUploadProperties fileUploadProperties;
	
	public String moveFile(String path,String fromDir,  String toDir) {
		Path staticPath=createStaticPath();
		if(path.indexOf(staticPath.toString())!=-1){
			path=path.replace(staticPath.toString(), "");
		}
		
		String staticPathStr=staticPath.toString()+path;
		Path pathFromMove=Paths.get(staticPathStr);
		String pathToMoveStr=staticPathStr.replace(fromDir, toDir);
		Path pathToMove=Paths.get(pathToMoveStr);
		Path pathToMoveParent=pathToMove.getParent();
		try {
			Files.createDirectories(pathToMoveParent);
			String fileName=pathToMove.toFile().getName();
			fileName=fileNameIncremanted(pathToMoveParent, fileName);
			pathToMove=pathToMoveParent.resolve(fileName);
			Files.copy(pathFromMove, pathToMove);
		}catch(Exception e) {
			e.printStackTrace();
		}
		Path completePath=Paths.get(pathToMove.toString()).normalize();
		Path complete2Path=Paths.get(pathFromMove.toString());
		log.info("Complete path is : {}", completePath);
		log.info("Complete 2nd path is : {}", complete2Path);
		
		return pathToMove.toString().replace(createStaticPath().toString(), "");
	}
	
	
	
	
	
	/**
	 * @param file is used to store in physical path
	 * @param ext is used to extention that can be append with file 
	 * @param dirName is used a directory name in which the file can be stored 
	 */
	private Path storeFile(MultipartFile file, String ext, String dirName) throws Exception  {	
		String fileName=createFileName(file.getOriginalFilename());	
		//fileName=fileName+ext;
		Path fileStorageLocationPath=createPath(dirName);
		try {			
			if(fileName.contains("..")) {
				throw new ApplicationContextException("Sorry! Filename contains invalid path sequence " + fileName);
			}
			Files.createDirectories(fileStorageLocationPath);
			
			Path targetLocation=fileStorageLocationPath.resolve(fileName);
			if(!targetLocation.toFile().exists()) {
				Files.copy(file.getInputStream(), 	targetLocation, StandardCopyOption.REPLACE_EXISTING);	
			}else {
				fileName=fileNameIncremanted(fileStorageLocationPath, fileName);
				//log.info("File list is : {}", fileList);
				Files.createDirectories(fileStorageLocationPath);
				targetLocation=fileStorageLocationPath.resolve(fileName);
				Files.copy(file.getInputStream(), 	targetLocation);
			}
			log.info("File stored on location : {}", targetLocation.toUri());
			
			return targetLocation;
			
		}catch(Exception e) {
			throw e;
		}
	}
	

	public FileReplaceDto replaceFile(String existFilePath, MultipartFile fileUploadModal) throws IOException {
		
		String staticPath=createStaticPath().toString();
		String str=existFilePath;
		String[] arr=str.split("/");
		String imagename=arr[arr.length-1];
		String completePath=imagename;
		//String completePath=existFilePath;
		if(imagename.indexOf(staticPath)==-1) {
			completePath=staticPath+File.separator+existFilePath;
		}
		Path replaceFilePath =Paths.get(completePath).normalize();
		
		String fileName=replaceFilePath.toFile().getName();
		
		deleteFile(replaceFilePath);
		String extOldFile=fileName.substring(fileName.indexOf("."));
		String extNewFile=fileUploadModal.getOriginalFilename().substring(fileUploadModal.getOriginalFilename().indexOf("."));
		String newFileName=fileName.replace(extOldFile, extNewFile);
		String originalFileName=fileNameIncremanted(replaceFilePath.getParent(), fileUploadModal.getOriginalFilename() );
		replaceFilePath=replaceFilePath.getParent().resolve(originalFileName);
		Path parentsReplaceFilePath=replaceFilePath.getParent();
		if(!parentsReplaceFilePath.toFile().exists())
			Files.createDirectories(parentsReplaceFilePath);
		
				Files.copy(fileUploadModal.getInputStream(), 	replaceFilePath, StandardCopyOption.REPLACE_EXISTING);
				String responsePath=replaceFilePath.toString().replace(staticPath, "");
			FileReplaceDto fileReplaceDto=new FileReplaceDto(responsePath, fileUploadModal.getContentType(), extNewFile);
			return fileReplaceDto;
	}
	 
	
	
	
	private String fileNameIncremanted(Path dirPath, String fileName){
		String extention="";
		if(fileName.lastIndexOf(".")!=-1){
			extention=fileName.substring(fileName.lastIndexOf("."));
			fileName=fileName.substring(0, fileName.lastIndexOf("."));
		}
		File file1=dirPath.toFile();
		log.info("File list is : {}", ""+file1.list(new FileSameNameFilter(fileName)));
		
		
		String[]arr=file1.list(new FileSameNameFilter(fileName))==null ? new String[0] : file1.list(new FileSameNameFilter(fileName));
		
		List<String> fileList=Arrays.asList(arr);
		int count=fileList.size();
	
		String contedFileName =fileName+"_"+count+extention;
		if(count==0) {
			contedFileName=fileName+extention;
		}
		Path newPathWithFile=dirPath.resolve(contedFileName);
		if(newPathWithFile.toFile().exists()) {
			return fileNameIncremanted(dirPath, contedFileName);
		}else {
			return contedFileName;
		}
		//return fileName+"_"+count+extention;
	}
	
	
	public Path createStaticPath() {
		return Paths.get(fileUploadProperties.getUploadDir()).toAbsolutePath().normalize();
	}
	
	
	/**
	 * @param fileUploadModals is used to store multiple file in physical location.
	 */
	public  FileSuccessResponseDto storeMultipleFile(List<FileUploadModal> fileUploadModals) {
		List<Path> paths=new ArrayList<>();
		List<FileResponse> fileResponseInternalDtos=new ArrayList<>();
		
		FileSuccessResponseDto fileSuccessResponseDto=null;
		
		try {
		for(FileUploadModal modal : fileUploadModals) {
				Path path=storeFile(modal.getFile(), modal.getExtension(), modal.getDirName());
				paths.add(path);
				FileResponse fileResponseInternalDto=new FileResponse(modal.getFile().getContentType(), path.toString());
				fileResponseInternalDtos.add(fileResponseInternalDto);
		}
		
		fileSuccessResponseDto=new FileSuccessResponseDto(paths, null, true, null);
		fileSuccessResponseDto.setPathAndTypes(fileResponseInternalDtos);
	
	} catch (Exception e) {
		e.printStackTrace();
		fileSuccessResponseDto=
				new FileSuccessResponseDto(null, fileUploadProperties.getNotWriteErrorCode(), false, fileUploadProperties.getNotWriteErrorDesc());
		fileSuccessResponseDto.setErrorCode(fileUploadProperties.getNotWriteErrorCode());
		fileSuccessResponseDto.setErrorDesc(fileUploadProperties.getNotWriteErrorDesc());
		fileSuccessResponseDto.setPath(null);
		fileSuccessResponseDto.setSuccess(false);	
		deleteFiles(paths);
	}
		return fileSuccessResponseDto;
	}
	
	
	public boolean deleteFiles(List<Path> paths) {
		try {
			for(Path path : paths) {
			 path.toFile().delete();
			}
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public boolean deleteFile(Path paths) {
		try {
			
			paths.toFile().delete();
			
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	
	public Path createPath(String dirName, boolean isTemp) {
		if(isTemp)
			this.fileStorageLocation=fileUploadProperties.getUploadDir()+File.separator+dirName+File.separator+fileUploadProperties.getTempFileDirName();
		else {
			 this.fileStorageLocation=fileUploadProperties.getUploadDir()+File.separator+dirName;
		}
		//this.fileStorageLocation=this.fileStorageLocation;
		return  Paths.get(this.fileStorageLocation)
				.toAbsolutePath()
				.normalize();
	}
	
	public Path createPath(String pathStr) {
		Path path= Paths.get(fileUploadProperties.getUploadDir());
		path.resolve(pathStr);
		return path;
	}
	
	
	@Override
	public String createFileName(String fileName){
		//SimpleDateFormat simpleDateFormat=new SimpleDateFormat(fileUploadProperties.getDateFormat());
//		fileName=fileName.replace(" ", "_");
//		int extIndex=fileName.lastIndexOf(".");
//		if(extIndex!=-1)
//		fileName=fileName.substring(0 ,  extIndex);
//		fileName=fileName+"_"+simpleDateFormat.format(Calendar.getInstance(Locale.getDefault()).getTime());
		return fileName;
	}
	
	@Override
	public Resource loadFileAsResource(String filePathUri) throws FileNotFoundException {
		try {
			Path filePath=createStaticPath();
			if(filePathUri.indexOf(filePath.toString())==-1) {
				String path1=filePath.toString()+File.separator+filePathUri;
				filePath=Paths.get(path1).normalize();
			}else {
				
			filePath = Paths.get(filePathUri).normalize();
			}
			Resource resource = new UrlResource(filePath.toUri());
			if (resource.exists()) {
				return resource;
			} else {
				throw new FileNotFoundException("File not found " + filePath);
			}
		} catch (MalformedURLException ex) {
			throw new FileNotFoundException("File not found " + filePathUri);
		}
	}

	
	
	@Override
	public Resource loadFileAsResourceForUser(String filePathUri) throws FileNotFoundException {
		try {
			//Path filePath=createStaticPath();
//			if(filePathUri.indexOf(filePath.toString())==-1) {
//				String path1=filePath.toString()+File.separator+filePathUri;
//				filePath=Paths.get(path1).normalize();
//			}else {
//			filePath = Paths.get(filePathUri).normalize();
//			}
			
			String staticPath=createStaticPath().toString();
			String completePath=filePathUri;
			if(filePathUri.indexOf(staticPath)==-1) {
				completePath=staticPath+File.separator+filePathUri;
			}
			
			Path filePath = Paths.get(completePath).normalize();
			
			Resource resource = new UrlResource(filePath.toUri());
			if (resource.exists()) {
				return resource;
			} else {
				throw new FileNotFoundException("File not found " + filePath);
			}
		} catch (MalformedURLException ex) {
			throw new FileNotFoundException("File not found " + filePathUri);
		}
	}

	
	@Override
	public FileSuccRespDto storeMultipleFile(FileUploadModal fileUploadModals) {
//List<Path> paths=new ArrayList<>();
		
		FileSuccRespDto fileSuccessResponseDto=null;
		Path path=null;
		try {
		//for(FileUploadModal modal : fileUploadModals) {
				path=storeFile(fileUploadModals.getFile(), fileUploadModals.getExtension(), fileUploadModals.getDirName());
				//paths.add(path);
		//}
		
		fileSuccessResponseDto=new FileSuccRespDto(null, true, null, path);
	
	} catch (Exception e) {
		fileSuccessResponseDto=
				new FileSuccRespDto(fileUploadProperties.getNotWriteErrorCode(), false, fileUploadProperties.getNotWriteErrorDesc(),null);
		fileSuccessResponseDto.setErrorCode(fileUploadProperties.getNotWriteErrorCode());
		fileSuccessResponseDto.setErrorDesc(fileUploadProperties.getNotWriteErrorDesc());
		fileSuccessResponseDto.setPaths(null);
		fileSuccessResponseDto.setSuccess(false);	
		deleteFile(path);
	}
		return fileSuccessResponseDto;

	}
	
	//Update image for not a multipart image
	
		public FileReplaceDto replaceFileNew(String existFilePath, BufferedImage img, String userId) throws IOException {
			String staticPath=createStaticPath().toString();
			String str=existFilePath;
			String[] arr=str.split("/");
			String imagename=arr[arr.length-1];
			String completePath=imagename;
			//String completePath=existFilePath;
			if(imagename.indexOf(staticPath)==-1) {
				completePath=staticPath+File.separator+existFilePath;
			}
			Path replaceFilePath =Paths.get(completePath).normalize();
			
			String fileName=replaceFilePath.toFile().getName();
			
			deleteFile(replaceFilePath);
				String originalFileName=fileNameIncremanted(replaceFilePath.getParent(), userId+new Date().getTime() );
			replaceFilePath=replaceFilePath.getParent().resolve(originalFileName);
			Path parentsReplaceFilePath=replaceFilePath.getParent();
			if(!parentsReplaceFilePath.toFile().exists())
				Files.createDirectories(parentsReplaceFilePath);
			File outputfile = replaceFilePath.toFile();
			 ImageIO.write(img, "jpg", outputfile); 
				Files.copy(outputfile.toPath(), replaceFilePath, StandardCopyOption.REPLACE_EXISTING);
					String responsePath=replaceFilePath.toString().replace(staticPath, "");
				FileReplaceDto fileReplaceDto=new FileReplaceDto(responsePath, "image/jpg", ".jpg");
				return fileReplaceDto;
		}


}