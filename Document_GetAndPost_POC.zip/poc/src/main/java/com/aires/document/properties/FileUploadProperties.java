package com.aires.document.properties;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "aires.file.upload")
public class FileUploadProperties {

	private String uploadDir;
	private String dateFormat;
	private String notWriteErrorCode;
	private String notWriteErrorDesc;
	private String tempUploadDir;
	private String tempFileDirName;
	private String historyDirName;
	private String deleteMessage;
	private String successCode;
	private String pathNotFound;

	public void setPathNotFound(String pathNotFound) {
		this.pathNotFound = pathNotFound;
	}

	public String getPathNotFound() {
		return pathNotFound != null ? pathNotFound : "File path not found!";
	}

	public void setDeleteMessage(String deleteMessage) {
		this.deleteMessage = deleteMessage;
	}

	public String getDeleteMessage() {
		return deleteMessage != null ? this.deleteMessage : "File deleted Successfully";
	}

	public void setHistoryDirName(String historyDirName) {
		this.historyDirName = historyDirName;
	}

	public String getHistoryDirName() {
		return historyDirName != null ? this.historyDirName : "history";
	}

	public void setTempFileDirName(String tempFileDirName) {
		this.tempFileDirName = tempFileDirName;
	}

	public String getTempFileDirName() {
		return tempFileDirName != null ? tempFileDirName : "temp";
	}

	private Map<String, String> contentTypesForAnnouncement = new HashMap<>();
	private Map<String, String> contentTypesForDocument = new HashMap<>();

	public void setTempUploadDir(String tempUploadDir) {
		this.tempUploadDir = tempUploadDir;
	}

	public String getTempUploadDir() {
		return tempUploadDir;
	}

	public String getNotWriteErrorCode() {
		return notWriteErrorCode == null ? "500" : notWriteErrorCode;
	}

	public void setNotWriteErrorCode(String notWriteErrorCode) {
		this.notWriteErrorCode = notWriteErrorCode;
	}

	public String getNotWriteErrorDesc() {
		return notWriteErrorDesc == null ? "File can not write" : notWriteErrorDesc;
	}

	public void setNotWriteErrorDesc(String notWriteErrorDesc) {
		this.notWriteErrorDesc = notWriteErrorDesc;
	}

	public Map<String, String> getContentTypesForAnnouncement() {
		return contentTypesForAnnouncement;
	}

	public void setContentTypesForAnnouncement(Map<String, String> contentTypesForAnnouncement) {
		this.contentTypesForAnnouncement = contentTypesForAnnouncement;
	}

	public Map<String, String> getContentTypesForDocument() {
		return contentTypesForDocument;
	}

	public void setContentTypesForDocument(Map<String, String> contentTypesForDocument) {
		this.contentTypesForDocument = contentTypesForDocument;
	}

	public String getUploadDir() {

		return uploadDir != null ? uploadDir : "./upload";
	}

	public void setUploadDir(String uploadDir) {
		this.uploadDir = uploadDir;
	}

	public String getDateFormat() {
		return dateFormat == null ? "yyyyMMdd_HHmmss" : dateFormat;
	}

	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getSuccessCode() {
		return successCode != null ? successCode : "0";
	}

	public void setSuccessCode(String successCode) {
		this.successCode = successCode;
	}

}
