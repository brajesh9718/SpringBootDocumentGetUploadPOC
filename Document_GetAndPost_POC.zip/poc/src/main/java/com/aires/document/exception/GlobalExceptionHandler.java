package com.aires.document.exception;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.aires.document.utils.Utility;

@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class GlobalExceptionHandler {

	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@Autowired
	private Environment env;

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<Object> generateExceptionResponse(final Throwable exp) {
		log.error("GlobalExceptionHandler: {}", exp);
		Map<String, String> map = new LinkedHashMap<String, String>();
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON_UTF8);
		if (exp instanceof ApplicationException) {
			ApplicationException exception = (ApplicationException) exp;
			map.put(exception.getErrorCode().trim(), exception.getMessage().trim());
		}  else {
			map.put(env.getProperty("general.exception.code").trim(),
					env.getProperty("general.exception.message"));
		}
		return new ResponseEntity<>(Utility.getFailureResponse(env.getProperty("response.failed.msg").trim(),
				env.getProperty("failure.code").trim(), map), header, HttpStatus.OK);
	}
}
