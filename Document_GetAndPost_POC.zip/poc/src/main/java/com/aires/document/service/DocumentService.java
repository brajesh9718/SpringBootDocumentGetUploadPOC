package com.aires.document.service;

import com.aires.document.dto.DocumentReq;
import com.aires.document.dto.DocumentResp;

public interface DocumentService {
	public int postDocument(DocumentReq documentReq) throws Exception;
	public DocumentResp getDocumentById(Integer documentId) throws Exception;
}
