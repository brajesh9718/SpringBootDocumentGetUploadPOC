package com.aires.document.serviceimpl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.aires.document.constant.Constant;
import com.aires.document.dto.DocumentReq;
import com.aires.document.dto.DocumentResp;
import com.aires.document.dto.FileResponse;
import com.aires.document.entity.Document;
import com.aires.document.exception.ApplicationException;
import com.aires.document.repository.DocumentRepository;
import com.aires.document.service.DocumentService;
import com.aires.document.service.FileStorageService;
import com.aires.document.utils.Utility;

@Service
public class DocumentServiceImpl implements DocumentService {
	private static final Logger LOG = LoggerFactory.getLogger(DocumentService.class);
	@Autowired
	Environment env;
	@Autowired
	private FileStorageService fileStorageService;
	@Autowired
	DocumentRepository docRepo;

	/**
	 * Document POST API
	 * 
	 * @param MultipartFile type
	 */
	@Override
	public int postDocument(DocumentReq documentReq) throws Exception {
		LOG.trace("Inside postDocument method: {}", documentReq);
		MultipartFile file = documentReq.getFile();
		if (null == file || file.isEmpty()) {
			throw new ApplicationException(env.getProperty("invalid.request.data.code"),
					env.getProperty("nodoc.found"));
		}
		FileResponse fileResp = Utility.getMultipartFilePath(file, fileStorageService);
		LOG.debug("file path: {} ", fileResp.getPath());
		Document documentEntity = new Document();
		documentEntity.setFilePath(fileResp.getPath());
		documentEntity.setFileType(fileResp.getFileType());
		documentEntity.setStatus(Constant.ACTIVE_STATUS);
		documentEntity.setCreatedOn(new Date());
		documentEntity = docRepo.save(documentEntity);
		return documentEntity.getDocumentId();
	}

	/**
	 * Document GET API by documentId
	 * 
	 * @param documentId
	 */
	@Override
	public DocumentResp getDocumentById(Integer documentId) throws Exception {
		LOG.trace("Inside getDocumentById method documentId is : {} ", documentId);
		Document document = docRepo.findByDocumentId(documentId);
		if (null == document) {
			throw new ApplicationException(env.getProperty("nodocument.foundcode"),
					env.getProperty("document.notfound"));
		}
		DocumentResp resp = new DocumentResp();
		resp.setDocumentId(document.getDocumentId());
		resp.setDocumentPath(document.getFilePath());
		resp.setDocumentType(document.getFileType());
		return resp;
	}

}
