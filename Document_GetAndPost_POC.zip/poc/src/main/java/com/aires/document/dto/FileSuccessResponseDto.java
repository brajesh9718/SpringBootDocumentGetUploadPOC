package com.aires.document.dto;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FileSuccessResponseDto {
	private String errorCode;
	private boolean success;
	private String errorDesc;
	private List<Path> paths;

	
	private List<FileResponse> pathAndTypes=new ArrayList<>();
	
	
	
	public FileSuccessResponseDto(List<Path> paths, String errorCode, boolean success, String errorDesc) {
		super();
		this.paths=paths;
		this.errorCode = errorCode;
		this.success = success;
		this.errorDesc = errorDesc;
	}
	
	public void setPathAndTypes(List<FileResponse> pathAndTypes) {
		this.pathAndTypes = pathAndTypes;
	}
	
	public List<FileResponse> getPathAndTypes() {
		return pathAndTypes;
	}
	
	public List<Path> getPath() {
		return paths;
	}
	public void setPath(List<Path> paths) {
		this.paths = paths;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
}
