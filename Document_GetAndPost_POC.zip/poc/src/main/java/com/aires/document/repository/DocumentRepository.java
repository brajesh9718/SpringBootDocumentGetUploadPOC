package com.aires.document.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aires.document.entity.Document;

public interface DocumentRepository extends JpaRepository<Document, Integer> {
	Document findByDocumentId(Integer documentId);

}
