package com.aires.document.dto;

public class FileResponse {

	String path;
	String fileType;
	
	public void setPath(String path) {
		this.path = path;
	}
	
	public String getPath() {
		return path;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
	public String getFileType() {
		return fileType;
	}
	
	public FileResponse(String fileType, String path) {
		this.fileType=fileType;
		this.path=path;
	}
}
