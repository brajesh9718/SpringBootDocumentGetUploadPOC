package com.aires.document.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.aires.document.dto.FileResponse;
import com.aires.document.dto.FileSuccessResponseDto;
import com.aires.document.dto.FileUploadModal;
import com.aires.document.exception.ApplicationException;
import com.aires.document.service.FileStorageService;
import com.aires.document.utils.ErrorResponse.ErrorDetails;

public class Utility {

	private static final Logger LOG = LoggerFactory.getLogger(Utility.class);

	/**
	 * 
	 * @param file
	 * @param fileStorageService                                                                                           
	 * @return FilePath and Type as well
	 * @throws Exception
	 */
	public static FileResponse getMultipartFilePath(final MultipartFile file,
			final FileStorageService fileStorageService) throws Exception {
		LOG.trace("inside getMultipartFilePath method:{}", file);
		StringBuilder builder = new StringBuilder(".");
		builder.append(FilenameUtils.getExtension(file.getOriginalFilename()));
		List<FileUploadModal> list = new ArrayList<>();
		FileUploadModal fileUploadModel = new FileUploadModal(file, builder.toString(), "Aires");
		list.add(fileUploadModel);
		FileSuccessResponseDto fileResponse = fileStorageService.storeMultipleFile(list);
		if (fileResponse == null) {
			LOG.info("Object not received from file upload service");
			throw new ApplicationException("405", "Some exception occurred at file upload service");
		} else {
			if (!fileResponse.isSuccess()) {
				LOG.debug("Some exception occurred at file upload service");
				throw new ApplicationException("405", "Some exception occurred at file upload service");
			} else {
				List<FileResponse> fileServiceResponse = fileResponse.getPathAndTypes();
				if (fileServiceResponse == null || fileServiceResponse.isEmpty()) {
					LOG.info("No path found");
					throw new ApplicationException("", "No path found");
				} else {
					return fileServiceResponse.get(0);
				}
			}
		}
	}

	public static Object getFailureResponse(final String description, final String responseCode,
			Map<String, String> map) {
		List<ErrorDetails> errors = new ArrayList<>();
		final ErrorResponse errorResponse = new ErrorResponse(description, responseCode);
		if (map == null) {
			map = new HashMap<>();
		}
		for (Map.Entry<String, String> key : map.entrySet()) {
			errors.add(errorResponse.getErrorDetailsObj(key.getKey(), key.getValue()));
		}
		errorResponse.setErrors(errors);
		return errorResponse;
	}

}
